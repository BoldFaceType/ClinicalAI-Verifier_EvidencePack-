"""Deterministic evidence extraction stubs."""
