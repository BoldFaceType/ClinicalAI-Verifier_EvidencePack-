"""Evidence strategy resolution."""
