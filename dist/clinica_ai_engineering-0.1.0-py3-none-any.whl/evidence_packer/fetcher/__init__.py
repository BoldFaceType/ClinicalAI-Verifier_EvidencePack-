"""Clinical evidence retrieval."""
